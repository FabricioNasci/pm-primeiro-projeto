package com.example.text;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {

    private Button btnCalcularNovamente;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        btnCalcularNovamente = findViewById(R.id.btnCalcularNovamente);
        btnCalcularNovamente.setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });

        String imc = getIntent().getStringExtra("IMC");
        String classificacao = getIntent().getStringExtra("CLASSIFICACAO");


        TextView textViewImc = findViewById(R.id.textViewResultado1);
        TextView textViewClassificacao = findViewById(R.id.textViewResultado3);

        textViewImc.setText(imc);
        textViewClassificacao.setText("Classificação: " + classificacao);
    }


}
