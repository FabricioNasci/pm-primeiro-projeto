package com.example.text;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {
    private EditText textInputEditLogin;
    private EditText textInputEditSenha;
    private Button btnLogar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);


        textInputEditLogin = findViewById(R.id.TextInputEditLogin);
        textInputEditSenha = findViewById(R.id.textInputEditSenha);
        btnLogar = findViewById(R.id.btnLogar);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnLogar.setOnClickListener(view -> {
            String LoginInput = textInputEditLogin.getText().toString();
            String senhaInput = textInputEditSenha.getText().toString();

            if (LoginInput.equals("admin") && senhaInput.equals("admin")) {
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Login ou senha incorretos", Toast.LENGTH_SHORT).show();
            }
        });
    }


}