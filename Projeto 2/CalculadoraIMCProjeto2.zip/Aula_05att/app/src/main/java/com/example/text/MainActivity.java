package com.example.text;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    private Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btnCalcular = findViewById(R.id.btnCalcular);
        btnCalcular.setOnClickListener(this::calcular);
    }

    public void calcular(View view) {
        TextInputEditText camponome = findViewById(R.id.textInputNome);
        TextInputEditText campopeso = findViewById(R.id.textInputPeso);
        TextInputEditText campoaltura = findViewById(R.id.textInputAltura);
        RadioGroup radioGroupGenero = findViewById(R.id.radioGroupGenero);

        String nome = camponome.getText().toString().trim();
        String peso = campopeso.getText().toString().trim();
        String altura = campoaltura.getText().toString().trim();
        int selectedId = radioGroupGenero.getCheckedRadioButtonId();


        if (nome.isEmpty()) {
            camponome.setError("Preencher o campo Nome");
            fecharTeclado(view);
            return;
        }
        if (peso.isEmpty()) {
            campopeso.setError("Preencher o campo Peso");
            fecharTeclado(view);
            return;
        }
        if (altura.isEmpty()) {
            campoaltura.setError("Preencher o campo Altura");
            fecharTeclado(view);
            return;
        }
        if (selectedId == -1) {

            return;
        }

        Double numPeso;
        Double numAltura;
        try {
            numPeso = Double.parseDouble(peso);
            numAltura = Double.parseDouble(altura);
        } catch (NumberFormatException e) {

            return;
        }

        Double numImc = numPeso / (numAltura * numAltura);
        DecimalFormat df = new DecimalFormat("##.##");
        String imc = df.format(numImc);
        String classificacao = "";

        // Classificação
        if (selectedId == R.id.radioMasculino) {
            if (numImc > 43) {
                classificacao = "Obesidade Mórbida";
            } else if (numImc >= 30) {
                classificacao = "Obesidade Moderada";
            } else if (numImc >= 25) {
                classificacao = "Obesidade Leve";
            } else if (numImc >= 20) {
                classificacao = "Normal";
            } else {
                classificacao = "Abaixo do Normal";
            }
        } else if (selectedId == R.id.radioFeminino) {
            if (numImc > 39) {
                classificacao = "Obesidade Mórbida";
            } else if (numImc >= 30) {
                classificacao = "Obesidade Moderada";
            } else if (numImc >= 24) {
                classificacao = "Obesidade Leve";
            } else if (numImc >= 19) {
                classificacao = "Normal";
            } else {
                classificacao = "Abaixo do Normal";
            }
        }


        Intent intent = new Intent(this, MainActivity3.class);
        intent.putExtra("IMC", imc);
        intent.putExtra("CLASSIFICACAO", classificacao);
        startActivity(intent);

        fecharTeclado(view);
    }

    public void fecharTeclado(View view) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public void limpar(View view) {
        TextInputEditText camponome = findViewById(R.id.textInputNome);
        TextInputEditText campopeso = findViewById(R.id.textInputPeso);
        TextInputEditText campoaltura = findViewById(R.id.textInputAltura);
        RadioGroup radioGroupGenero = findViewById(R.id.radioGroupGenero);

        camponome.setText("");
        campopeso.setText("");
        campoaltura.setText("");
        radioGroupGenero.clearCheck();

    }
}
