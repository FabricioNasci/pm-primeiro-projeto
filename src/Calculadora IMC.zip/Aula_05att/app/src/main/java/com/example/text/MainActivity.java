package com.example.text;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void calcular(View view) {
        TextInputEditText camponome = findViewById(R.id.textInputNome);
        TextInputEditText campopeso = findViewById(R.id.textInputPeso);
        TextInputEditText campoaltura = findViewById(R.id.textInputAltura);
        RadioGroup radioGroupGenero = findViewById(R.id.radioGroupGenero);

        TextView resultado1 = findViewById(R.id.textViewResultado1);
        TextView resultado2 = findViewById(R.id.textViewResultado3);

        String nome = camponome.getText().toString().trim();
        String peso = campopeso.getText().toString().trim();
        String altura = campoaltura.getText().toString().trim();
        int selectedId = radioGroupGenero.getCheckedRadioButtonId();

        // Verificação dos campos
        if (nome.isEmpty()) {
            camponome.setError("Preencher o campo Nome");
            fecharTeclado(view);
            return;
        }
        if (peso.isEmpty()) {
            campopeso.setError("Preencher o campo Peso");
            fecharTeclado(view);
            return;
        }
        if (altura.isEmpty()) {
            campoaltura.setError("Preencher o campo Altura");
            fecharTeclado(view);
            return;
        }
        if (selectedId == -1) {
            resultado1.setText("Preencher o campo Gênero");
            fecharTeclado(view);
            return;
        }

        String genero = selectedId == R.id.radioMasculino ? "Masculino" : "Feminino";

        Double numPeso;
        Double numAltura;
        try {
            numPeso = Double.parseDouble(peso);
            numAltura = Double.parseDouble(altura);
        } catch (NumberFormatException e) {
            resultado1.setText("Entrada inválida");
            return;
        }

        Double numImc = numPeso / (numAltura * numAltura);

        DecimalFormat df = new DecimalFormat("##.##");
        String imc = df.format(numImc);

        resultado1.setText(imc);

        String classificacao = "";

        if (genero.equals("Masculino")) {
            if (numImc > 43) {
                classificacao = "Obesidade Mórbida";
                resultado2.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            } else if (numImc >= 30 && numImc <= 39.9) {
                classificacao = "Obesidade Moderada";
                resultado2.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            } else if (numImc >= 25 && numImc <= 29.9) {
                classificacao = "Obesidade Leve";
                resultado2.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            } else if (numImc >= 20 && numImc <= 24.9) {
                classificacao = "Normal";
                resultado2.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            } else {
                classificacao = "Abaixo do Normal";
                resultado2.setTextColor(getResources().getColor(android.R.color.holo_orange_light));
            }
        } else if (genero.equals("Feminino")) {
            if (numImc > 39) {
                classificacao = "Obesidade Mórbida";
                resultado2.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            } else if (numImc >= 30 && numImc <= 38.9) {
                classificacao = "Obesidade Moderada";
                resultado2.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            } else if (numImc >= 24 && numImc <= 28.9) {
                classificacao = "Obesidade Leve";
                resultado2.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            } else if (numImc >= 19 && numImc <= 23.9) {
                classificacao = "Normal";
                resultado2.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            } else {
                classificacao = "Abaixo do Normal";
                resultado2.setTextColor(getResources().getColor(android.R.color.holo_orange_light));
            }
        }

        resultado2.setText(classificacao);
        fecharTeclado(view);
    }
    public void fecharTeclado(View view) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public void limpar(View view){
        TextInputEditText camponome = findViewById(R.id.textInputNome);
        TextInputEditText campopeso = findViewById(R.id.textInputPeso);
        TextInputEditText campoaltura = findViewById(R.id.textInputAltura);
        TextView resultado1 = findViewById(R.id.textViewResultado1);
        TextView resultado2 = findViewById(R.id.textViewResultado3);
        RadioGroup radioGroupGenero = findViewById(R.id.radioGroupGenero);

        camponome.setText("");
        campopeso.setText("");
        campoaltura.setText("");
        resultado1.setText("");
        resultado2.setText("");
        radioGroupGenero.clearCheck();
    }
}

